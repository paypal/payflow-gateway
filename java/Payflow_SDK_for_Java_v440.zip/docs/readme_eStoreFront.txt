
Copyright (c) 2006 PayPal Inc. All Rights Reserved
----------------------------------------------

This readme will guide you to use eStoreFront deployable samples for 
BuyerAuth and Express Checkout with the Payflow SDK for Java .


TO DEPLOY THE ESTOREFRONT ON THE TOMCAT SERVER
------------------------------------------------
1. Copy The entire eStoreFront directory shipped with the Payflow SDK for Java  to the 
 'webapps' directory of your Apache Tomcat installation directory.

2. Compile the paypal.estorefront package present under the servlets directory 
 of eStoreFront and place it under the WEB-INF\classes directory. This has already been
 done for you. Ensure that if you make any modification to the servlet classes, you 
 compile them and place it here.

3. Ensure that the payflow.jar is present under the WEB-INF\lib directory of the eStoreFront.

4. Initial values and user Information for the SDK can be changed using the eStoreProperties.properties
 file. Note that putting user information in the properties file is not advisable. It has been 
 done here since this is just a sample project. Ensure that you set all mandatory parameters here, lest
 the eStoreFront errors out

5. Download the Xerces-J 2.7.1 package (XML parser) called Xerces-J-bin.2.7.1.tar.gz 
 from Apache�s archive download Web site at http://archive.apache.org/dist/xml/xerces-j/

6. Place the Xerces jars (xercesImpl.jar and xml-apis.jar) under the WEB-INF\lib directory 
 of the eStoreFront.

7. Start the tomcat server by using the startup.bat file present in the Bin folder of 
 your Tomcat installation directory.

8. Connect to http://localhost:<tomcat_port>/eStoreFront/home using your web browser.
 Proceed with the instructions on the displayed page.

9. To know which port your tomcat server is pointing to open the server.xml file present
 at tomcat installation \conf\ directory. The current port is specified by the �port� attribute 
 of the 'Connector' tag.

10. Note: every time you hit http://localhost:<tomcat_port>/eStoreFront/home , the
 properties in the eStoreProperties.properties will be reloaded.
 
11. Details of all orders will be persisted in the directory webapps\eStoreFront\web\orders.
 Ensure that this directory exists and is given write access.

