package paypal.estorefront;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PurchaseCompleteServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
            throws IOException, ServletException {
        String auth = request.getParameter("auth");
        String message = request.getParameter("msg");
        StringBuffer purchaseStatus = new StringBuffer();

        String greetings;
        if ("NO".equals(auth)) {
            purchaseStatus.append(message).append("<br>Clicking \"Return to Cart\" will restart the purchase.");
            greetings = "Sorry ...";
        } else if ("YES".equals(auth)) {
            String orderId = (String) request.getSession().getAttribute("orderId");
            String orderFolder = getServletContext().getRealPath(EStoreConstants.ORDER_FOLDER);
            try {
                Properties order = new Properties();
                order.load(new FileInputStream(orderFolder + File.separator + orderId + ".ord"));

                greetings = "<div style=\"FONT_SIZE:medium\"><b>Thank you ...</b><div>";
                purchaseStatus.append("Your order is placed successfully. Order details as shown:")
                        .append("<br><br><TABLE id='Table1' style='Z-INDEX: 103; LEFT: 72px; WIDTH: 488px;'")
                        .append("cellSpacing='1' cellPadding='0' width='300' border='0' align='left'>")
                        .append("<TR align='left'><TD><STRONG>Cart</STRONG></TD><TD><STRONG>Total</STRONG></TD></TR>")
                        .append("<TR align='left'><TD>Lord of the rings. </TD><TD>0.56</TD></TR>")
                        .append("<TR><TD>State Sales Tax</TD><TD>0.44</TD></TR>")
                        .append("<TR><TD><b>Order Total:</b></TD><TD>1.00</TD></TR></TABLE><br>")
                        .append("<br><br><br><br><br><b>Payment Method:</b>		")
                        .append(order.get("payMethod"));

                if ("Credit Card".equals(order.get("payMethod"))) {
                    String firstName = (String) order.get("firstName");
                    String lastName = (String) order.get("lastName");
                    String street = (String) order.get("street");
                    String city = (String) order.get("city");
                    String state = (String) order.get("state");
                    String zip = (String) order.get("zip");
                    StringBuffer billingInfo = new StringBuffer("<br><br><b>Billing Address:</b><br>")
                            .append("<blockquote>")
                            .append(null != firstName ? firstName : "").append(" ")
                            .append(null != lastName ? lastName : "").append("<br>")
                            .append(null != street ? street : "").append("<br>")
                            .append(null != city ? city : "").append("<br>")
                            .append(null != state ? state : "").append(", ")
                            .append(null != zip ? zip : "").append("</blockquote>");
                    if (!"<br><br><b>Billing Address:</b><br><blockquote> <br><br><br>, </blockquote>"
                            .equals(billingInfo.toString())) {
                        purchaseStatus.append("<HR style=\"BACKGROUND-COLOR: blue\" align=\"left\" width=\"92%\" SIZE=\"8\" color=\"#146690\">")
                                .append(billingInfo);
                    }
                }
                String shipToFName = (String) order.get("shipToFName");
                String shipToLName = (String) order.get("shipToLName");
                String shipToStreet = (String) order.get("shipToStreet");
                String shipToCity = (String) order.get("shipToCity");
                String shipToState = (String) order.get("shipToState");
                String shipToZip = (String) order.get("shipToZip");
                StringBuffer shipping = new StringBuffer().append("<br><br><b>Shipping Address:</b><br>")
                        .append("<blockquote>")
                        .append(null != shipToFName ? shipToFName : "").append(" ")
                        .append(null != shipToLName ? shipToLName : "").append("<br>")
                        .append(null != shipToStreet ? shipToStreet : "").append("<br>")
                        .append(null != shipToCity ? shipToCity : "").append("<br>")
                        .append(null != shipToState ? shipToState : "").append(", ")
                        .append(null != shipToZip ? shipToZip : "").append("<br>").append("</blockquote>");
                if (!"<br><br><b>Shipping Address:</b><br><blockquote> <br><br><br>, <br></blockquote>".equals(shipping.toString())) {
                    purchaseStatus.append("<HR style=\"BACKGROUND-COLOR: blue\" align=\"left\" width=\"92%\" SIZE=\"8\" color=\"#146690\">")
                            .append(shipping);
                }
            }
            catch (Exception e) {
                e.printStackTrace();
                purchaseStatus = new StringBuffer("Although your order was succesfully placed, an error occurred while retrieving order details")
                        .append("<br>Clicking \"Return to Cart\" will restart the purchase.");
                greetings = "Sorry...";
            }
        } else {
            purchaseStatus.append("Your order could not be completed at this time." + "<br>Clicking \"Return to Cart\" will restart the purchase.");
            greetings = "Sorry ...";
        }

        response.setContentType("text/html");
        PrintStream out = new PrintStream(response.getOutputStream());
        out.println("<Html>");
        out.println("<Head>");
        out.println("<Title>Purchase Complete");
        out.println("</Title>");
        out.println("</Head>");
        out.println("<body> <font face=\"VERDANA\">");
        out.println("<div>");
        out.println(greetings);
        out.println("</div>");
        out.println("<HR style=\"BACKGROUND-COLOR: blue\" align=\"left\" width=\"92%\" SIZE=\"8\" color=\"#146690\">");
        out.println(purchaseStatus);
        out.println("<HR style=\"BACKGROUND-COLOR: blue\" align=\"left\" width=\"92%\" SIZE=\"8\" color=\"#146690\">");
        out.println("<form action=\"home\">");
        out.println("<input type =\"Submit\" value =\"Return To Cart\" ");
        out.println("</font></body>");
        out.println("</html>");
        out.flush();
        out.close();
    }

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
            throws IOException, ServletException {
        doGet(request, response);
    }

}
