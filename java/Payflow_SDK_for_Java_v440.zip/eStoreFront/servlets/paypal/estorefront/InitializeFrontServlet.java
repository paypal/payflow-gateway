package paypal.estorefront;

import java.io.FileInputStream;
import java.io.IOException;
//import java.net.URL;
import java.net.URLEncoder;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import paypal.payflow.*;

public class InitializeFrontServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
            throws IOException, ServletException {
        try {
            Properties properties = new Properties();
            properties.load(new FileInputStream(getServletContext().getRealPath(EStoreConstants.PROPERTY_FILE)));
            SDKProperties.setHostAddress(properties.getProperty("hostAddress"));
            try {
                SDKProperties.setHostPort(Integer.parseInt(properties.getProperty("hostPort")));
            } catch (NumberFormatException e) {
                e.printStackTrace();
                String message = "Invalid Host Port value.";
                response.sendRedirect("PurchaseComplete?auth=NO&msg=" + URLEncoder.encode(message, "UTF-8"));
            }
            SDKProperties.setProxyAddress(properties.getProperty("proxyAddress"));
            try {
                SDKProperties.setProxyPort(Integer.parseInt(properties.getProperty("proxyPort")));
            } catch (NumberFormatException e) {
                SDKProperties.setProxyPort(0);
            }
            SDKProperties.setProxyLogin(properties.getProperty("proxyLogin"));
            SDKProperties.setProxyPassword(properties.getProperty("proxyPassword"));
            try {
                SDKProperties.setLoggingLevel(Integer.parseInt(properties.getProperty("loggingLevel")));
            } catch (NumberFormatException e) {
                e.printStackTrace();
                String message = "Invalid Logging Level value.";
                response.sendRedirect("PurchaseComplete?auth=NO&msg=" + URLEncoder.encode(message, "UTF-8"));
            }
            try {
                SDKProperties.setMaxLogFileSize(Integer.parseInt(properties.getProperty("maxLogFileSize")));
            } catch (NumberFormatException e) {
                e.printStackTrace();
                String message = "Invalid Maximum Log File Size value.";
                response.sendRedirect("PurchaseComplete?auth=NO&msg=" + URLEncoder.encode(message, "UTF-8"));
            }
            SDKProperties.setLogFileName(properties.getProperty("logFileName"));
            try {
                SDKProperties.setTimeOut(Integer.parseInt(properties.getProperty("timeOut")));
            } catch (NumberFormatException e) {
                e.printStackTrace();
                String message = "Invalid Time Out value.";
                response.sendRedirect("PurchaseComplete?auth=NO&msg=" + URLEncoder.encode(message, "UTF-8"));

            }
            SDKProperties.setStackTraceOn("true".equals(properties.getProperty("stackTraceOn")));
            String BAUser = properties.getProperty("BAUser");
            String BAVendor = properties.getProperty("BAVendor");
            String BAPartner = properties.getProperty("BAPartner");
            String BAPassword = properties.getProperty("BAPassword");
            EStoreConstants.setPayFlowBAUser(new UserInfo(BAUser, BAVendor, BAPartner, BAPassword));
            String ECUser = properties.getProperty("ECUser");
            String ECVendor = properties.getProperty("ECVendor");
            String ECPartner = properties.getProperty("ECPartner");
            String ECPassword = properties.getProperty("ECPassword");
            String paypalECServer = properties.getProperty("paypalECServer");
            EStoreConstants.setPaypalECServer(paypalECServer);
            EStoreConstants.setPayFlowECUser(new UserInfo(ECUser, ECVendor, ECPartner, ECPassword));
            response.sendRedirect("jsp/PurchaseDescription.jsp");
        }
        catch (Exception e) {
            e.printStackTrace();
            String message = "An internal Error occured";
            response.sendRedirect("PurchaseComplete?auth=NO&msg=" + URLEncoder.encode(message, "UTF-8"));
        }

    }

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
            throws IOException, ServletException {
        doGet(request, response);
    }
}
