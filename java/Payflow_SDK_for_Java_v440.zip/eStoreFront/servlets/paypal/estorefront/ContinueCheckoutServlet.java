package paypal.estorefront;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import paypal.payflow.AuthorizationTransaction;
import paypal.payflow.Currency;
import paypal.payflow.ECDoRequest;
import paypal.payflow.Invoice;
import paypal.payflow.PayflowConnectionData;
import paypal.payflow.PayflowUtility;
import paypal.payflow.PayPalTender;
import paypal.payflow.TransactionResponse;

public class ContinueCheckoutServlet extends HttpServlet {
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
            throws IOException, ServletException {
        String token = request.getSession().getAttribute("token").toString();
        String payerId = request.getSession().getAttribute("payerId").toString();
        Double amount = new Double(request.getSession().getAttribute("amount").toString());
        if (token != null && token.trim().length() != 0) {
            // Once the customer has reviewed the shipping details and decides to continue
            // checkout by clicking on "Continue Checkout" button, it's time to actually
            // authorize the transaction.
            // This is the third step in PayPal Express Checkout, in which you need to perform a
            // DO operation to authorize the purchase amount.
            // Create a DO request.
            ECDoRequest doRequest = new ECDoRequest(token, payerId);
            Invoice inv = new Invoice();
            inv.setAmt(new Currency(amount));
            // Create the Tender.
            PayPalTender paypalTender = new PayPalTender(doRequest);

            // Create a transaction.
            AuthorizationTransaction trans = new AuthorizationTransaction
                    (EStoreConstants.getPayFlowECUser(),
                            new PayflowConnectionData(),
                            inv,
                            paypalTender,
                            PayflowUtility.getRequestId());
            // Submit the transaction.
            trans.submitTransaction();
            boolean success = false;
            int authResult = trans.getResponse().getTransactionResponse().getResult();
            System.out.println("request = " + trans.getResponse().getRequestString());
            System.out.println("response = " + trans.getResponse().getResponseString());
            if (authResult >= 0) {
                success = true;

            }

            if (authResult == 0) {
                // Store the response params in the order details.
                // You should store PNREF, AVSADDR, AVSZIP, CVV2MATCH
                String orderFolder = getServletContext().getRealPath(EStoreConstants.ORDER_FOLDER);
                String orderId = (String) request.getSession().getAttribute("orderId");
                synchronized (this) {
                    try {
                        File orderFile = new File(orderFolder + File.separator + orderId + ".ord");
                        System.out.println("order Info saved into : " + orderFile.getParentFile().getAbsolutePath());
                        if (orderFile.exists()) {
                            TransactionResponse trnsResponse = trans.getResponse().getTransactionResponse();
                            PrintStream fps = new PrintStream(new FileOutputStream(orderFile, true), true);
                            fps.println("pnRef = " + trnsResponse.getPnref());
                            fps.println("pPRef = " + trnsResponse.getPPRef());
                            fps.println("avsAddr = " + trnsResponse.getAvsAddr());
                            fps.println("avsZip = " + trnsResponse.getAvsZip());
                            fps.close();
                        } else {
                            throw new Exception();
                        }
                        response.sendRedirect("PurchaseComplete?auth=YES");
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                        String message = "Your order was successfully completed, but we are unable to display the order Info at this time.";
                        response.sendRedirect("PurchaseComplete?auth=NO&msg=" + URLEncoder.encode(message, "UTF-8"));
                    }
                }
            } else {
                String message = "Your order cannot be completed at this time.";
                if (success) {
                    message += "Please check your PayPal details.";
                } else {
                    message += "An internal error occurred";
                }
                response.sendRedirect("PurchaseComplete?auth=NO&msg=" + URLEncoder.encode(message, "UTF-8"));
            }
        }
    }

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
            throws IOException, ServletException {
        doGet(request, response);
    }
}
