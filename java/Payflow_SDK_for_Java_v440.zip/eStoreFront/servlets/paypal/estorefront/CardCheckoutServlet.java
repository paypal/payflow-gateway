package paypal.estorefront;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import paypal.payflow.AuthorizationTransaction;
import paypal.payflow.BillTo;
import paypal.payflow.BuyerAuthResponse;
import paypal.payflow.BuyerAuthStatus;
import paypal.payflow.BuyerAuthVATransaction;
import paypal.payflow.BuyerAuthVETransaction;
import paypal.payflow.CardTender;
import paypal.payflow.CreditCard;
import paypal.payflow.Currency;
import paypal.payflow.Invoice;
import paypal.payflow.PayflowConnectionData;
import paypal.payflow.PayflowUtility;
import paypal.payflow.Response;
import paypal.payflow.ShipTo;

public class CardCheckoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
            throws IOException, ServletException {

        try {
            String orderId = request.getParameter("orderId");
            if (orderId != null && orderId.length() > 0) {
                request.getSession().setAttribute("orderId", orderId);
                persistOrderDetails(orderId, request);
                String[] baArr = request.getParameterValues("buyerAuth");
                String buyerAuth = "";
                if (baArr != null && baArr.length > 0) {
                    buyerAuth = baArr[0];
                }
                if ("YES".equals(buyerAuth)) {
                    doVerifyEnrollmentAndRedirect(request, response);
                } else {
                    AuthorizationTransaction authtrans = null;
                    try {
                        authtrans = populatetransaction(orderId);
                    }
                    catch (Exception cnfEx) {
                        String Msg = "Error ocurred during persisting the order details. Please check the access rights on 'orders' folder";
                        response.sendRedirect("PurchaseComplete?auth=NO&msg=" + Msg);
                    }
                    if (authtrans != null) {
                        authtrans.submitTransaction();
                    }
                    showStatusAndRedirect(authtrans, request, response);
                }
            } else {
                String pares = request.getParameter("PaRes");
                orderId = request.getParameter("MD");
                request.getSession().setAttribute("orderId", orderId);
                BuyerAuthVATransaction validateAuthtrans = new BuyerAuthVATransaction(EStoreConstants.getPayFlowBAUser(), new PayflowConnectionData(), pares, PayflowUtility.getRequestId());

                Response validateAuthResp = validateAuthtrans.submitTransaction();

                if (validateAuthResp.getTransactionResponse().getResult() >= 0) {

                }
                AuthorizationTransaction authTrans = null;
                try {
                    authTrans = populatetransaction(orderId);
                }
                catch (Exception cnfEx) {
                    String Msg = "Error ocurred during persisting the order details. Please check the access rights on 'orders' folder";
                    response.sendRedirect("PurchaseComplete?auth=NO&msg=" + Msg);
                }

                BuyerAuthResponse baResp = validateAuthResp.getBuyerAuthResponse();

                BuyerAuthStatus baStatus = new BuyerAuthStatus();
                baStatus.setAuthenticationId(baResp.getAuthenticationId());
                baStatus.setAuthenticationStatus(baResp.getAuthenticationStatus());
                baStatus.setCavv(baResp.getCavv());
                baStatus.setEci(baResp.getEci());
                baStatus.setXid(baResp.getXid());

                if (authTrans != null) {
                    authTrans.setBuyerAuthStatus(baStatus);
                }
                if (authTrans != null) {
                    authTrans.submitTransaction();
                }
                showStatusAndRedirect(authTrans, request, response);

            }

        }
        catch (IOException Ignore) {
            Ignore.printStackTrace();
            String Msg = "Error ocurred during persisting the order details. Please check the access rights on 'orders' folder";
            response.sendRedirect("PurchaseComplete?auth=NO&msg=" + Msg);

        }

    }

    private void showStatusAndRedirect(AuthorizationTransaction trans, HttpServletRequest request, HttpServletResponse response) throws IOException {
        boolean success = false;
        if (trans.getResponse().getTransactionResponse().getResult() >= 0) {
            success = true;

        }
        System.out.println(trans.getResponse().getRequestString());
        System.out.println(trans.getResponse().getResponseString());
        if (trans.getResponse().getTransactionResponse().getResult() == 0) {
            response.sendRedirect("PurchaseComplete?auth=YES");
        } else {
            String message = "Your order cannot be completed at this time.";

            // If result code is greater than 0 (Zero), the transaction is discarded
            // by the Payflow server. The reason why the transaction is discarded is
            // evident by the result code value and therefore, you should look at this
            // result code and decide if
            // 1. The customer has given some wrong inputs,
            // 2. It's a fraudulent transaction.
            // 3. There's a problem with your merchant account credentials etc.
            // (This is more likely to be caught in your test scenarios.)
            if (success) {
                // Here you can decide what message needs to be shown to
                // the customer based on the result code returned by the Payflow
                // Pro service.
                message += "Please check your credit card details.";
            } else {
                // A negative result code means there was an error thrown from the
                // Payflow SDK for Java . Pls make sure that your configurations is
                // correct.
                message += "An internal error occurred";
            }

            response.sendRedirect("PurchaseComplete?auth=NO&msg=" + URLEncoder.encode(message, "UTF-8"));
        }

    }

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
            throws IOException, ServletException {
        doGet(request, response);
    }

    private void persistOrderDetails(String orderId, HttpServletRequest request) throws IOException {

        // Before proceeding with transaction processing, you should persist the order details.
        // The details of the order that are generally persisted are:
        // Credit card details : Card Number, Expiry date ( Card CVV2 number cannot be stored).
        // Billing address details, shipping address details.
        // Storing these details helps you to allow a returning customer to do a faster
        // checkout, having his/her details already populated in the desired fields.
        // Storing the ordering details is generally uses database.
        // Here, however for the demonstration purpose, this web application stores the order
        // details in a flat file named <order_id>.ord and retrieves it later.
        // Note that this is not a recommended method to persist order details.

        String orderFolder = getServletContext().getRealPath(EStoreConstants.ORDER_FOLDER);
        File orderFile = new File(orderFolder + File.separator + orderId + ".ord");
        if (orderFile.exists()) {
            orderFile.delete();
        }
        orderFile.createNewFile();
        PrintStream order = new PrintStream(new FileOutputStream(orderFile, true), true);

        order.println("creditCardNumber = " + request.getParameter("creditCardNumber"));
        order.println("expDate = " + request.getParameter("expMonth") + request.getParameter("expYear"));
        order.println("amount = " + request.getParameter("amount"));
        order.println("firstName = " + request.getParameter("firstName"));
        order.println("lastName = " + request.getParameter("lastName"));
        order.println("city = " + request.getParameter("city"));
        order.println("zip = " + request.getParameter("zip"));
        order.println("state = " + request.getParameter("state"));
        order.println("street = " + request.getParameter("street"));
        order.println("shipToState = " + request.getParameter("shipToState"));
        order.println("shipToFName = " + request.getParameter("shipToFirstName"));
        order.println("shipToLName = " + request.getParameter("shipToLastName"));
        order.println("shipToStreet = " + request.getParameter("shipToStreet"));
        order.println("shipToCity = " + request.getParameter("shipToCity"));
        order.println("shipToZip = " + request.getParameter("shipToZip"));
        order.println("shipToState = " + request.getParameter("shipToState"));
        order.println("payMethod = " + "Credit Card");

        order.close();
    }


    private void doVerifyEnrollmentAndRedirect(HttpServletRequest request, HttpServletResponse response) throws IOException {

        // Create the Credit card object.
        CreditCard Card = new CreditCard(request.getParameter("creditCardNumber"),
                request.getParameter("expMonth") + request.getParameter("expYear"));

        // Create the currency object for amount.
        // Here the currency code is the 3 digit ISO country code.
        // For US -> USD.
        Currency Amt = new Currency(new Double(request.getParameter("amount")), "USD");

        // Create a Verify Enrollment transaction.
        BuyerAuthVETransaction trans = new BuyerAuthVETransaction
                (EStoreConstants.getPayFlowBAUser(),
                        Card, new PayflowConnectionData(),
                        Amt,
                        PayflowUtility.getRequestId());

        // Submit the transaction.
        Response Resp = trans.submitTransaction();

        System.out.println(trans.getResponse().getResponseString());
        // Redirect to the ACS ( Access Control Server, eg. users' bank)
        // The URL to ACS and PaReq (Payer Authentication Request --
        // digitally signed, encrypted request to authenticate user's enrollment
        // upon his/her login is returned in the response of verify enrollment.
        // This happens if, the user is enrolled for buyerauth and the transaction succeeds.
        if (Resp.getTransactionResponse().getResult() == 0) {

            // Check if the user is enrolled for the buyer authentication service.
            // If the AUTHENTICATION_STATUS response parameter is E, means user is
            // enrolled for this service. If so, redirect the user's browser  as follows
            // to his/her bank's secure URL with PaReq, both obtained in ACSURL response parameter:
            // In this you can use the MD field to set any descriptive field or a key to your persisted
            // order details (such as order id), which are required to retrive later on.
            // TermUrl is the URL of the page of your web application where the bank's secure server will
            // redirect the PaRes as the authentication response to for further processing.
            if ("E".equals(Resp.getBuyerAuthResponse().getAuthenticationStatus())) {
                // This means the user has enrolled him/her self for the buyer authentication
                // service. Therefore, now the user should be redirected to his/her bank's secure
                // server.
                StringBuffer returnUrl = null;
                try {
                    URL url = new URL(request.getProtocol().substring(0, request.getProtocol().indexOf('/'))
                            , request.getServerName()
                            , request.getServerPort()
                            , request.getContextPath());
                    returnUrl = new StringBuffer(url.toExternalForm());
                    returnUrl.append("/CardCheckout");

                } catch (MalformedURLException e) {
                    //To change body of catch statement use File | Settings | File Templates.
                }

                StringBuffer redirectUrl = new StringBuffer(trans.getResponse().getBuyerAuthResponse().getAcsUrl());
                redirectUrl.append("?PaReq=");
                redirectUrl.append(java.net.URLEncoder.encode(trans.getResponse().getBuyerAuthResponse().getPaReq().trim(), "UTF-8"));
                redirectUrl.append("&TermUrl=");
                redirectUrl.append(returnUrl);
                redirectUrl.append("&MD=");
                redirectUrl.append(request.getParameter("orderId"));

                response.sendRedirect(redirectUrl.toString());
            } else {

                // If the user is not enrolled for buyer authentication,
                // take the decision accornding to your business logic whether to
                // allow the transaction to proceed or not.
                // Here in this ficitous store front, the decision is taken to go
                // ahead with an authorization.
                AuthorizationTransaction authTrans = null;
                try {
                    authTrans = populatetransaction(request.getParameter("orderId"));
                }
                catch (Exception Ex) {
                    String Msg = "Error ocurred during persisting the order details. Please check the access rights on 'orders' folder";
                    response.sendRedirect("PurchaseComplete?auth=NO&msg=" + Msg);

                }
                if (authTrans != null) {
                    authTrans.submitTransaction();
                }
                showStatusAndRedirect(authTrans, request, response);

            }

        } else {
            String Msg = "An internal error has occurred.";
            response.sendRedirect("PurchaseComplete?auth=NO&msg=" + Msg);
        }


    }


    private AuthorizationTransaction populatetransaction(String orderId) throws IOException, ClassNotFoundException {
        String orderFolder = getServletContext().getRealPath(EStoreConstants.ORDER_FOLDER);
        File orderFile = new File(orderFolder + File.separator + orderId + ".ord");

        Properties orderTable = new Properties();
        orderTable.load(new FileInputStream(orderFile));

        BillTo Bill = new BillTo();
        Bill.setFirstName((String) orderTable.get("firstName"));
        Bill.setLastName((String) orderTable.get("lastName"));
        Bill.setStreet((String) orderTable.get("street"));
        Bill.setCity((String) orderTable.get("city"));
        Bill.setState((String) orderTable.get("state"));
        Bill.setZip((String) orderTable.get("zip"));

        ShipTo Ship = new ShipTo();
        Ship.setShipToFirstName((String) orderTable.get("shipToFName"));
        Ship.setShipToLastName((String) orderTable.get("shipToLName"));
        Ship.setShipToStreet((String) orderTable.get("shipToStreet"));
        Ship.setShipToCity((String) orderTable.get("shipToCity"));
        Ship.setShipToState((String) orderTable.get("shipToState"));
        Ship.setShipToZip((String) orderTable.get("shipToZip"));

        CreditCard creditCard = new CreditCard((String) orderTable.get("creditCardNumber"), (String) orderTable.get("expDate"));
        CardTender cardTender = new CardTender(creditCard);

        Invoice inv = new Invoice();

        Currency amt = new Currency(new Double((String) orderTable.get("amount")));
        inv.setAmt(amt);

        return new AuthorizationTransaction(EStoreConstants.getPayFlowBAUser(), new PayflowConnectionData(), inv, cardTender, PayflowUtility.getRequestId());
    }

}
