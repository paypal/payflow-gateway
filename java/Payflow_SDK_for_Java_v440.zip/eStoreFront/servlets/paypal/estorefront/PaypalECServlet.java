package paypal.estorefront;

import java.io.IOException;
import java.net.URL;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import paypal.payflow.AuthorizationTransaction;
import paypal.payflow.Currency;
import paypal.payflow.ECSetRequest;
import paypal.payflow.Invoice;
import paypal.payflow.PayflowConnectionData;
import paypal.payflow.PayPalTender;
import paypal.payflow.Response;


public class PaypalECServlet extends HttpServlet {
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
            throws IOException, ServletException {
        String token;
        Invoice inv = new Invoice();
        Double amt = new Double(request.getParameter("amount"));
        inv.setAmt(new Currency(amt));
        String orderId = request.getParameter("orderId");
        URL url = new URL(
                request.getProtocol().substring(0, request.getProtocol().indexOf('/'))
                , request.getServerName()
                , request.getServerPort()
                , request.getContextPath());

        String returnURL = new StringBuffer(url.toExternalForm())
                .append("/PaypalDetails?").append(request.getQueryString())
                        //.append("&orderid=").append(orderId)
                .toString();
        String cancelURL = new StringBuffer(url.toExternalForm())
                .append("/PurchaseComplete").toString();
        ECSetRequest setRequest = new ECSetRequest(
                returnURL, cancelURL);

        token = request.getParameter("token");
        // Check if Token passed is null or not.
        // If the token passed is not null, it means,
        // the user wants to edit the shipping details and therefore,
        // the page PaypalDetailsServlet has redirected the request back to this page.
        // PaypalDetailsServlet has passed Token (session token) and orderid in the querystring
        // We will hence do a repeated SET operation passing the current session id rather than
        // obtaining one.
        // If the token passed is null, it means, it is a new express checkout
        // process. Therefore, by doing a SET operation, we should obtain a session
        // token from paypal and later on redirect the user's browser to the paypal site
        // with this session token.
        if (token != null && token.trim().length() != 0) {
            setRequest.setToken(token);
        }

        PayPalTender paypalTender = new PayPalTender(setRequest);

        AuthorizationTransaction trans = new AuthorizationTransaction(
                EStoreConstants.getPayFlowECUser(),
                new PayflowConnectionData(),
                inv,
                paypalTender,
                orderId);
        Response resp = trans.submitTransaction();
        if (resp != null) {
            System.out.println("request = " + resp.getRequestString());
            System.out.println("response = " + resp.getResponseString());
            System.out.println(resp.getContext());
        }
        int authResult = trans.getResponse().getTransactionResponse().getResult();
        boolean success = false;
        if (authResult >= 0) {
            success = true;

        }

        if (authResult == 0) {
            // If the SET operation succeeds,
            // you will get a secure session token id in the response of this operation.
            // Using this token, redirect the user's browser as follows:
            // Here is the sample redirection url:
            // https://www.paypal.com/us/cgi-bin/webscr?cmd=_express-checkout&token=<token obtained in SET response.>
            String paypalUrl = new StringBuffer("https://" + EStoreConstants.getPaypalECServer() + "?cmd=_express-checkout&token=")
                    .append(trans.getResponse().getEcSetResponse().getToken()).toString();
            response.sendRedirect(paypalUrl);
        } else {
            // Do the error handling here according to your design and business logic.
            // This is a sample error handling code for this fictious estorefront.
            String message = "Your order cannot be completed at this time. ";
            if (success) {
                message = message.concat("Please check your credit card details.");
            } else {
                message = message.concat("An internal error occurred");
            }
            response.sendRedirect("PurchaseComplete?auth=NO&msg=" + URLEncoder.encode(message, "UTF-8"));
        }
    }

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
            throws IOException, ServletException {
        doGet(request, response);
    }
}
