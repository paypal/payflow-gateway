package paypal.estorefront;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import paypal.payflow.AuthorizationTransaction;
import paypal.payflow.ECGetRequest;
import paypal.payflow.ECGetResponse;
import paypal.payflow.PayflowConnectionData;
import paypal.payflow.PayflowUtility;
import paypal.payflow.PayPalTender;


public class PaypalDetailsServlet extends HttpServlet {
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
            throws IOException, ServletException {
        String token = request.getParameter("token");
        String orderId = request.getParameter("orderId");
        request.getSession().setAttribute("orderId", orderId);
        request.getSession().setAttribute("amount", request.getParameter("amount"));

        StringBuffer resultHtmlBody = new StringBuffer();
        if (token != null && token.trim().length() != 0) {
            // Calling a GET operation is second step in PayPal
            // Express checkout process. Once the customner has logged into
            // his/her paypal account, selected shipping address and clicked on
            // "Continue checkout", the paypal server will redirect the page to
            // the ReturnUrl you have specified in the previous SET request.
            // To obtain the shipping details chosen by the Customer, you will
            // then need to do a GET operation.
            // Create a Get request.
            ECGetRequest getRequest = new ECGetRequest(token);

            // Create the Tender.
            PayPalTender paypalTender = new PayPalTender(getRequest);

            // Create a transaction.
            AuthorizationTransaction trans = new AuthorizationTransaction
                    (EStoreConstants.getPayFlowECUser(),
                            new PayflowConnectionData(),
                            null,
                            paypalTender,
                            PayflowUtility.getRequestId());

            // Submit the transaction.
            trans.submitTransaction();

            boolean success = false;
            int authResult = trans.getResponse().getTransactionResponse().getResult();
            if (authResult >= 0) {
                success = true;

            }

            if (authResult == 0) {
                ECGetResponse ecGetResponse = trans.getResponse().getEcGetResponse();
                // You have now obtained the customer's order details in the response of
                // Get operation. Show these order details for review to the customer and persist them.
                resultHtmlBody
                        .append("<b>SHIPPING DETAILS : </b> <br><table> <tr><td>")
                        .append(ecGetResponse.getFirstName()).append(" ")
                        .append(ecGetResponse.getLastName()).append(",<br>")
                        .append(ecGetResponse.getShipToStreet()).append(",<br>")
                        .append(ecGetResponse.getShipToCity()).append(",<br>")
                        .append(ecGetResponse.getShipToState()).append(",<br>")
                        .append(ecGetResponse.getShipToZip()).append("</td></tr></table>");
                request.getSession().setAttribute("payerId", ecGetResponse.getPayerId());
                request.getSession().setAttribute("token", token);
                String orderFolder = getServletContext().getRealPath(EStoreConstants.ORDER_FOLDER);
                File orderFile = new File(orderFolder + File.separator + orderId + ".ord");

                PrintStream fps = new PrintStream(new FileOutputStream(orderFile), true);
                fps.println("shipToFName = " + ecGetResponse.getFirstName());
                fps.println("shipToLName = " + ecGetResponse.getLastName());
                fps.println("shipToStreet = " + ecGetResponse.getShipToStreet());
                fps.println("shipToCity = " + ecGetResponse.getShipToCity());
                fps.println("shipToZip = " + ecGetResponse.getShipToState());
                fps.println("shipToState = " + ecGetResponse.getShipToState());
                fps.println("payMethod = " + "PAYPAL");
                fps.close();

            } else {
                String message = "Your order cannot be completed at this time.";
                if (success) {
                    message += "Please check your PayPal details.";
                } else {
                    message += "An internal error occurred";
                }
                response.sendRedirect("PurchaseComplete?auth=NO&msg=" + URLEncoder.encode(message, "UTF-8"));
            }
        }
        response.setContentType("text/html");
        PrintStream out = new PrintStream(response.getOutputStream());
        out.println("<html>");
        out.println("	<head>");
        out.println("     <title>Shipping Details</title>");
        out.println("  </head>");
        out.println("<body><font face=\"VERDANA\">");
        out.println("   <div style=\" FONT-SIZE:medium\"><b>Review your Shipping Address</b></div>");
        out.println("<HR style=\"BACKGROUND-COLOR: blue\" align=\"left\" width=\"92%\" SIZE=\"8\" color=\"#146690\">");
        out.print(resultHtmlBody);
        out.println("<HR style=\"BACKGROUND-COLOR: blue\" align=\"left\" width=\"92%\" SIZE=\"8\" color=\"#146690\">");
        out.println("   <form action=\"ContinueCheckout\">");
        out.println("   <input type=\"hidden\" name=\"auth\" value=\"YES\"/>");
        out.println("	  <input type=\"submit\" name=\"Continue\" value=\"Continue\"></input>");
        out.println("     </form>");
        out.println(" </font>  </body>");
        out.println("</html>");
        out.close();
    }

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
            throws IOException, ServletException {
        doGet(request, response);
    }
}
