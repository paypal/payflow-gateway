package paypal.estorefront;

import java.io.File;

import paypal.payflow.UserInfo;

public class EStoreConstants {
    private static UserInfo payFlowECUser = new UserInfo("<user>", "<vendor>", "<partner>", "<password>");
    private static UserInfo payFlowBAUser = new UserInfo("<user>", "<vendor>", "<partner>", "<password>");
    protected static final String ORDER_FOLDER = "web" + File.separator + "orders";
    public static final String PROPERTY_FILE = "properties" + File.separator + "eStoreProperties.properties";
    private static String paypalECServer = "www.paypal.com/us/cgi-bin/webscr";

    protected static UserInfo getPayFlowBAUser() {
        return payFlowBAUser;
    }

    protected static void setPayFlowBAUser(UserInfo payFlowBAUser) {
        EStoreConstants.payFlowBAUser = payFlowBAUser;
    }

    protected static UserInfo getPayFlowECUser() {
        return payFlowECUser;
    }

    protected static void setPayFlowECUser(UserInfo payFlowECUser) {
        EStoreConstants.payFlowECUser = payFlowECUser;
    }

    protected static String getPaypalECServer() {
        return paypalECServer;
    }

    protected static void setPaypalECServer(String paypalECServer) {
        if (null != paypalECServer && paypalECServer.length() != 0)
            EStoreConstants.paypalECServer = paypalECServer;
    }


}