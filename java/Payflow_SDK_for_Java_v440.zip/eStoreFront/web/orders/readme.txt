This folder will be populated with *.ord files containing details of orders placed through the eStoreFront.
Ensure that this folder is given write access.