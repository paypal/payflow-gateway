This file contains v4.45 of the Payflow .NET SDK which has been compliled to support TLS 1.2.  It was compiled using v4.5 of the .NET SDK and only supports TLS 1.2 and is not backwards compatible with any other version of TLS.

This is a direct replacement of the current .DLL on your system and should require no code changes.  However, if using in COM (Classic ASP) you must un-register, delete old .DLL and re-register new one.

The Payflow Developer Guides can be found at https://developer.paypal.com/docs/classic/products/payflow.

If you run into any problems, please email DL-PP-Payflow-SDK@paypal.com.