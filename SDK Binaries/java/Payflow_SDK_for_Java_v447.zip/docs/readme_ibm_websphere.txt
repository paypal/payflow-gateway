To use the Java SDK with IBM WebSphere (WAS) you will need to set the URL Stream 
Handler property, SDKProperties.setURLStreamHandlerClass("");

To determine which class to use, find /opt/IBM/WebSphere/ -name "ibmjsse*"

For example, you might find the jsse as:

   /opt/IBM/WebSphere/AppServer/java/jre/lib/ibmjsseprovider2.jar.

This jar file will contain the handler class you need set in the SDK property.

Examples of classes and handlers are:

   * ibmjsseprovider.jar, com.ibm.net.ssl.www.protocol.https.Handler
   * ibmjsseprovider2.jar, com.ibm.net.ssl.www2.protocol.https.Handler
 

Also note that you might need to import new root certificates if you see an error in the
log file similar to this:

   * javax.net.ssl.SSLHandshakeException: com.ibm.jsse2.util.h: No trusted certificate found


To import a certificate, do the following:

  1. Log in to the WAS admin console.
  2. Go to Security -> SSL certificate and key management
  3. Continue to Key stores and certificates -> NodeDefaultTrustStore
  4. And finally to Signer certificates
  5. Select Retrieve from port from the button bar to import certificate
  6. Restart WAS